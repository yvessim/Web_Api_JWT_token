﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;

namespace WebApi.Mapper
{
    public static class Mapper
    {

        public static User ToApi(this User u)
        {
            User usr = new User();
            usr.Id = u.Id;
            usr.FirstName = u.FirstName;
            usr.LastName = u.LastName;
            usr.Password = u.Password;

            return usr;

        }

       


    }
}
